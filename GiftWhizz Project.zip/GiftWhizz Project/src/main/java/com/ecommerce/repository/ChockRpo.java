package com.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.entity.Chockolate;

public interface ChockRpo extends JpaRepository<Chockolate, Long> {

}
